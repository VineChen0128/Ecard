﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Ecard
{
    public partial class test1 : Form
    {
        SqlConnection conn = null;
        public test1()
        {
            InitializeComponent();
        }

        private void test1_Load(object sender, EventArgs e)
        {
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string b = textBox2.Text.Trim();
            string a = textBox1.Text.Trim();
            string c = comboBox1.Text.Trim();
            string d = comboBox2.Text.Trim();
            SelsectHelp.update1(b, a);
            string sql = SelsectHelp.selectmohu(c, d);
            dataGridView1.DataSource = SelsectHelp.showdgv(sql).Tables[0];
            
        }

        private void dataRepeater1_CurrentItemIndexChanged(object sender, EventArgs e)
        {

        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            textBox1.Text = dataGridView1.Rows[e.RowIndex].Cells[0].Value.ToString().Trim();
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void comboBox1_DropDown(object sender, EventArgs e)
        {
            comboBox1.DataSource = SelsectHelp.combomdrop1().Tables[0];
            comboBox1.DisplayMember = "a";
        }

        private void comboBox2_DropDown(object sender, EventArgs e)
        {
            comboBox2.DataSource = SelsectHelp.combomdrop2().Tables[0];
            comboBox2.DisplayMember = "b";
        }

        private void button2_Click(object sender, EventArgs e)
        {

            string a = comboBox1.Text.Trim();
            string b = comboBox2.Text.Trim();
            string sql = SelsectHelp.selectmohu(a,b);
            conn = new SqlConnection(SQLHelper.connString);
            
            dataGridView1.DataSource = SelsectHelp.showdgv(sql).Tables[0];
            SqlCommand scmd = new SqlCommand(sql, conn);
            conn.Open();
            if (scmd.ExecuteScalar() == null)
                MessageBox.Show("查询无果");
            conn.Close();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            string a = textBox3.Text.Trim();
            string b = textBox4.Text.Trim();
            string c = textBox5.Text.Trim();
            SelsectHelp.insert1(a, b, c);
            string sql = SelsectHelp.selectGLYB();
            dataGridView1.DataSource = SelsectHelp.showdgv(sql).Tables[0];
        }

        private void test1_FormClosing(object sender, FormClosingEventArgs e)
        {
            //SqlConnection conn = new SqlConnection(SQLHelper.connString);
            //conn.Open();
            //string sql = string.Format("insert into T1 values('{0}','{1}','{2}') ", "closing", "closing", "closing");
            //SqlCommand scmd = new SqlCommand(sql, conn);
            //scmd.ExecuteScalar();
            //conn.Close();
        }

        private void test1_FormClosed(object sender, FormClosedEventArgs e)
        {
            //SqlConnection conn = new SqlConnection(SQLHelper.connString);
            //conn.Open();
            //string sql = string.Format("insert into T1 values('{0}','{1}','{2}') ", "closed", "closed", "closed");
            //SqlCommand scmd = new SqlCommand(sql, conn);
            //scmd.ExecuteScalar();
            //conn.Close();
        }

        private void loadData()
        {
            string constr = "server = (local);database = ceshi;User ID=sa;Password=sasasa";
            using (SqlConnection conn = new SqlConnection(constr))
            {
                string sql = "usp_fenye4";  //sql语句变成存储过程名
                DataSet ds = new DataSet();
                DataView mydv = new DataView();
                //DataTable dt = new DataTable();
                using (SqlDataAdapter sqlData = new SqlDataAdapter(sql, constr))
                {
                    sqlData.SelectCommand.CommandType = CommandType.StoredProcedure;
                    sqlData.Fill(ds,"1");
                    
                    mydv = new DataView(ds.Tables["c"]);
                    //this.dataGridView1.DataSource = dt;
                    //mydv = new DataView(ds.Tables["c"]);

                    //ds.Clear();
                    //conn = new SqlConnection(SQLHelper.connString);
                    //conn.Open();
                    //sda1 = new SqlDataAdapter(sql, conn);
                    //sda1.Fill(ds, "c");
                    dataGridView1.DataSource = ds.Tables[0];
                    dataGridView1.DataSource = ds.Tables[1];
                }
            }
        }
        private void button4_Click(object sender, EventArgs e)
        {

            loadData();
        }
    }
}
