﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Ecard
{
    public partial class TakeOutMoney : UserControl
    {
        public TakeOutMoney()
        {
            InitializeComponent();
        }
        SqlConnection conn;
        DataSet ds = new DataSet();
        DataView mydv = new DataView();
        SqlDataAdapter sda1 = null;

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void TakeOutMoney_Load(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                if (textBox1.Text.Trim() == "")
                {
                    MessageBox.Show("请输入一卡通卡号！");//检测卡号是否为空
                }
                else
                {
                    conn = new SqlConnection(SQLHelper.connString);
                    conn.Open();
                    ds.Clear();
                    string a = textBox1.Text.Trim();//获取输入的卡号
                    string sql = string.Format("select CID from KXXB where CID='{0}'", a);//格式化查询语句
                    SqlCommand sqlcmd = new SqlCommand(sql, conn);//执行查询命令
                    //Object ifexist = sqlcmd.ExecuteScalar();//保存命令第一行第一列
                    if (sqlcmd.ExecuteScalar() == null)//判断卡号是否存在
                    {
                        MessageBox.Show("一卡通卡号不存在");
                    }
                    else
                    {
                        string sql2 = string.Format("select CID 卡号,SIDORTIDORPID 学号或工号或编号,MONEY 余额,CSTATUS 卡状态 from KXXB where CID='{0}'", a);
                        sda1 = new SqlDataAdapter(sql2, conn);
                        sda1.Fill(ds, "a");
                        mydv = new DataView(ds.Tables["a"]);
                        dataGridView1.DataSource = ds.Tables[0];
                    }
                    conn.Close();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
    }

        private void button1_Click(object sender, EventArgs e)
        {
            ds.Clear();
            try 
            {
                if (maskedTextBox1.Text.Trim() == "")
                {
                    MessageBox.Show("请输入提现金额！");//检测提现金额是否为空
                }
                else if (Convert.ToDouble(maskedTextBox1.Text.Trim()) <= 0.00)
                {
                    MessageBox.Show("提现金额异常");
                }
                else
                {//maskedTextBox1
                    double Tmoney = Convert.ToDouble(maskedTextBox1.Text.Trim());//获取提现金额
                    conn = new SqlConnection(SQLHelper.connString);
                    conn.Open();
                    ds.Clear();
                    string ID = textBox1.Text.Trim();//获取输入的卡号
                    string sql = string.Format("select Money from KXXB where CID='{0}'", ID);//格式化查询语句
                    SqlCommand sqlcmd = new SqlCommand(sql, conn);//执行查询命令
                    double Qmoney = Convert.ToDouble(sqlcmd.ExecuteScalar());//获取余额数值
                    if (Tmoney > Qmoney)
                    {
                        MessageBox.Show("余额不足！");//检测提现金额是否合理
                    }
                    else
                    {
                        double Tmoney1 = Convert.ToDouble(maskedTextBox1.Text.Trim());
                        string sql2 = string.Format("update KXXB set Money=Money - {0} where CID = '{1}' ", Tmoney1, ID);//更新账户扣款
                        SqlCommand sqlcmd2 = new SqlCommand(sql2, conn);
                        sqlcmd2.ExecuteNonQuery();
                        string sql3 = "select getdate()";
                        SqlCommand sqlcmd3 = new SqlCommand(sql3, conn);
                        sqlcmd3.ExecuteNonQuery();
                        String Ltime = Convert.ToString(sqlcmd3.ExecuteScalar());
                        String LID = "TX" + Ltime;
                        string sql4 = string.Format("insert into LSXXB values('{0}','{1}','system','{2}', '{3}')", LID, ID, Tmoney, Ltime);//生成提现流水信息
                        SqlCommand sqlcmd4 = new SqlCommand(sql4, conn);
                        sqlcmd4.ExecuteNonQuery();

                        string sql5 = string.Format("select ChargeWay from CZJLB where CID = '{0}'order by paytime desc", ID);
                        SqlCommand sqlcmd5 = new SqlCommand(sql5, conn);
                        if (Convert.ToInt32(sqlcmd5.ExecuteScalar()) == 1)
                        {
                            MessageBox.Show("提现成功");
                        }
                        else
                        {
                            string sql8 = string.Format("select PayID from CZJLB where CID = '{0}'order by paytime desc", ID);
                            SqlCommand sqlcmd8 = new SqlCommand(sql8, conn);
                            string PayID = Convert.ToString(sqlcmd8.ExecuteScalar());
                            string sql7 = string.Format("update ZFBB set PayMoney =PayMoney + '{0}' where PayID ='{1}'", Tmoney1, PayID);
                            SqlCommand sqlcmd7 = new SqlCommand(sql7, conn);
                            sqlcmd7.ExecuteNonQuery();
                            MessageBox.Show("支付宝到账！");
                        }

                    }
                    string sql6 = string.Format("select CID 卡号,SIDORTIDORPID 学号或工号或编号,MONEY 余额,CSTATUS 卡状态 from KXXB where CID='{0}'", ID);//更新卡信息表
                    SqlCommand sqlcmd6 = new SqlCommand(sql6, conn);
                    sqlcmd6.ExecuteNonQuery();
                    sda1 = new SqlDataAdapter(sql6, conn);
                    sda1.Fill(ds, "a");
                    mydv = new DataView(ds.Tables["a"]);
                    dataGridView1.DataSource = ds.Tables[0];
                    conn.Close();
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show("请输入完整的金额数值，精确到小数点2位！");
            }  
        }

        private void textBox3_KeyPress(object sender, KeyPressEventArgs e)
        {

           
        }
    }        
}