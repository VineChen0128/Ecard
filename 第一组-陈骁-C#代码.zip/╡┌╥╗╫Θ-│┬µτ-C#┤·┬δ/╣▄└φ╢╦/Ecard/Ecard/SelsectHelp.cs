﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.SqlClient;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Windows.Forms;

namespace Ecard
{
    class SelsectHelp
    {
        static SqlConnection conn = null;
        public static string selectGLYB()
        {
            string sql = string.Format("select a 编号, b 班级, c 人数 from T1 ");
            return sql;
        }
        public static string selectmohu(string a , string b)
        {
            string sql = string.Format("select a 编号, b 班级, c 人数 from T1 where a like '%{0}%' and b like '%{1}%'",a,b);
            
            return sql;
        }
        public static void update1(string b, string a)
        {
            conn = new SqlConnection(SQLHelper.connString);
            conn.Open();
            string sql = string.Format("update T1 set b = '{0}' where a = '{1}'",b,a);
            SqlCommand cmdse_SID = new SqlCommand(sql, conn);
            cmdse_SID.ExecuteScalar();
            conn.Close();
        }
        public static DataSet showdgv(string sql)
        {            
            SqlDataAdapter sda1 = null;
            DataSet ds = new DataSet();
            DataView mydv = new DataView();
            ds.Clear();
            conn = new SqlConnection(SQLHelper.connString);
            conn.Open();
            sda1 = new SqlDataAdapter(sql, conn);
            sda1.Fill(ds, "c");
            mydv = new DataView(ds.Tables["c"]);
            conn.Close();
            return ds;
        }
        public static void insertGLYB(string a,string b,string c,int d)
        {
            SqlConnection conn = new SqlConnection(SQLHelper.connString);
            conn.Open();
            string sql = string.Format("insert into GLYB (ID ,Password ,Glname ,QX ) values ( '{0}','{1}','{2}',{3})", a, b, c, d);
            SqlCommand cmdse_SID = new SqlCommand(sql, conn);
            cmdse_SID.ExecuteScalar();
            conn.Close();
        }

        public static void resetPassword(string a)
        {
            SqlConnection conn = new SqlConnection(SQLHelper.connString);
            conn.Open();
            string sql = string.Format("update  GLYB set Password = 000000 where ID= '{0}'", a);
            SqlCommand cmdse_SID = new SqlCommand(sql, conn);
            cmdse_SID.ExecuteScalar();
            conn.Close();
        }

        public static void insert1(string a, string b, string c)
        {
            SqlConnection conn = new SqlConnection(SQLHelper.connString);
            conn.Open();
            string sql = string.Format("insert into T1 values('{0}','{1}','{2}') ", a,b,c);
            SqlCommand scmd = new SqlCommand(sql, conn);
            scmd.ExecuteScalar();
            conn.Close();
        }
        public static DataSet combomdrop1()
        {
            conn = new SqlConnection(SQLHelper.connString);
            conn.Open();
            SqlDataAdapter sda_cbb7 = new SqlDataAdapter();
            DataSet ds = new DataSet();
            sda_cbb7 = new SqlDataAdapter("select distinct a from T1 order by a desc", conn);
            sda_cbb7.Fill(ds, "0");
            conn.Close();
            return ds;
        }
        public static DataSet combomdrop2()
        {
            conn = new SqlConnection(SQLHelper.connString);
            conn.Open();
            SqlDataAdapter sda_cbb7 = new SqlDataAdapter();
            DataSet ds = new DataSet();
            sda_cbb7 = new SqlDataAdapter("select distinct b from T1 order by b desc", conn);
            sda_cbb7.Fill(ds, "0");
            conn.Close();
            return ds;
        }
        
    }
}
