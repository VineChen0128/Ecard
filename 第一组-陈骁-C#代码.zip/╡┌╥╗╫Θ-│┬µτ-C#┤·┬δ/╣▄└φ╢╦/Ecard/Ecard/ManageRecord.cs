﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;


namespace Ecard
{
    public partial class ManageRecord : UserControl
    {
        SqlConnection conn = null;
        DataSet ds = new DataSet();
        DataSet ds2 = new DataSet();
        DataView mydv = new DataView();

        public ManageRecord()
        {
            InitializeComponent();
            conn = new SqlConnection(SQLHelper.connString);
            
        }
        string cxLID;
        string cxCID;
        string cxMID;
        double cxREMO;
        DateTime cxRETI;
        

        private void button1_Click(object sender, EventArgs e)
        {
            conn = new SqlConnection(SQLHelper.connString);
            conn.Open();
            SqlDataAdapter sda = new SqlDataAdapter("Select LID 流水号,CID 卡号,MID 商家编号,EXCHANGEMONEY 交易金额,EXCHANGETIME 交易时间 from LSXXB", conn);
            DataSet ds = new DataSet();
            sda.Fill(ds);
            DataTable dt = ds.Tables[0];
            dataGridView1.DataSource = dt;
            conn.Close();          
        }
        private void button2_Click(object sender, EventArgs e)
        {
            conn = new SqlConnection(SQLHelper.connString);
            conn.Open();
            string sqlchaxun = string.Format("Select LID 流水号,CID 卡号,MID 商家编号,EXCHANGEMONEY 交易金额,EXCHANGETIME 交易时间  from LSXXB where LID = '{0}'", textBox2.Text.Trim());
            SqlDataAdapter sda = new SqlDataAdapter(sqlchaxun, conn);
            DataSet ds2 = new DataSet();
            sda.Fill(ds2);
            DataTable dt2 = ds2.Tables[0];
            dataGridView2.DataSource = dt2;
            conn.Close();
        }
       




        //判断条件进行查询
        private void button1_Click_1(object sender, EventArgs e)
        {
            if (textBox1.Text != "")
            {
                if(comboBox1.Text == "流水号")
                {
                    lsh();
                }
                else if (comboBox1.Text == "学号")
                {
                    xh();
                }
                else 
                {
                    kh();
                }
            }

            else 
            {
                MessageBox.Show("内容不能为空！");
            }
        }


        //判断条件进行查询
        private void button2_Click_1(object sender, EventArgs e)
        {
            if (textBox2.Text != "")
            {
                lsh();
            }
            else
            {
                MessageBox.Show("内容不能为空！");
            }
        }



        //绑定 DataGridView
        private void DataGridViewForm_Load(object sender, EventArgs e)
        {                 
            SqlConnection conn = null;
            try
            {
                conn = new SqlConnection(SQLHelper.connString);
                conn.Open();
                string sql = "select * from LSXXB l inner join KXXB k on l.CID=k.CID where l.CID IN (select * from CHJLB) ";
                SqlDataAdapter sda = new SqlDataAdapter(sql, conn);
                DataSet ds = new DataSet();
                sda.Fill(ds);
                dataGridView1.DataSource = ds.Tables[0];
            }
            catch (Exception ex)
            {
                MessageBox.Show("出现错误！" + ex.Message);
            }
            finally
            {
                if (conn != null)
                {                    
                    conn.Close();
                }
            }
        }


        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (comboBox1.Text == "流水号") 
            {
                textBox1.Text = "";
            }
            else if (comboBox1.Text == "学号")
            {
                textBox1.Text = "";
            }
            else 
            {
                textBox1.Text = "";
            }
        }


        private void SelectRecord_Load(object sender, EventArgs e)
        {
            comboBox1.SelectedIndex = comboBox1.Items.IndexOf("流水号");
        }

      
        private void dataGridView2_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            textBox3.Text = dataGridView2.Rows[e.RowIndex].Cells[0].Value.ToString();

            cxLID = dataGridView2.Rows[e.RowIndex].Cells[0].Value.ToString();
            cxCID = dataGridView2.Rows[e.RowIndex].Cells[1].Value.ToString();
            cxMID = dataGridView2.Rows[e.RowIndex].Cells[2].Value.ToString();
            cxREMO = Convert.ToDouble(dataGridView2.Rows[e.RowIndex].Cells[3].Value.ToString());
            cxRETI = Convert.ToDateTime( dataGridView2.Rows[e.RowIndex].Cells[4].Value.ToString());
        }

        private void button3_Click(object sender, EventArgs e)
        {
            conn.Open();
            if (textBox3.Text == "")
            {
                MessageBox.Show("请在左侧表格中选择需要撤销的一栏！");
            }
            else 
            {
                string sel_4 = string.Format("Select * from CHJLB where LID = '{0}'", textBox3.Text.Trim());
                SqlCommand cmdsel_4 = new SqlCommand(sel_4,conn);

                string sel_5 = string.Format("Select * from LSXXB where LID = '{0}' and MID = 'system'", textBox3.Text.Trim());
                SqlCommand cmdsel_5 = new SqlCommand(sel_5,conn);

                if (cmdsel_4.ExecuteScalar() != null)
                {
                    MessageBox.Show("该记录已撤回！");
                }
                else if (cmdsel_5.ExecuteScalar() != null)
                {
                    MessageBox.Show("该记录是退款信息，不可撤销！");
                }
                else
                {
                    insert();
                    select();
                    update();                
                }
            }
            conn.Close();
        }

        //流水号查询方法
        public void lsh()
        {
            string lsh = textBox1.Text;

            DataSet ds = new DataSet();
            SqlCommand cmd = conn.CreateCommand();

            cmd.CommandText = "select LID 流水号,CID 卡号,MID 商家编号,EXCHANGEMONEY 交易金额,EXCHANGETIME 交易时间 from LSXXB where LID='" + lsh + "'";
            conn = new SqlConnection(SQLHelper.connString);
            conn.Open();
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(ds);
            dataGridView1.DataSource = ds.Tables[0];
        }


        //学号查询方法
        public void xh()
        {
            string xh = textBox1.Text;

            DataSet ds = new DataSet();
            SqlCommand cmd = conn.CreateCommand();

            cmd.CommandText = "select LID 流水号, LSXXB.CID 卡号, MID 商家编号, ExchangeMoney 交易金额, ExchangeTime 交易时间 from LSXXB left join KXXB on LSXXB.CID=KXXB.CID where SIDorTIDorPID='" + xh + "'";
            conn = new SqlConnection(SQLHelper.connString);
            conn.Open();
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(ds);
            dataGridView1.DataSource = ds.Tables[0];
        }

        //卡号查询方法
        public void kh()
        {
            string kh = textBox1.Text;
           
            DataSet ds = new DataSet();
            SqlCommand cmd = conn.CreateCommand();

            cmd.CommandText = "select LID 流水号,CID 卡号,MID 商家编号,EXCHANGEMONEY 交易金额,EXCHANGETIME 交易时间 from LSXXB where CID='" + kh + "'";
            conn = new SqlConnection(SQLHelper.connString);
            conn.Open();
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(ds);
            dataGridView1.DataSource = ds.Tables[0];
        }


        //查询撤回记录表方法
        public void lsh2()
        {
            string lsh = textBox2.Text;
            //string connStr = "server= 112.111.12.4; Database=XYYKT;Integrated Security=SSPI";
            conn = new SqlConnection(SQLHelper.connString);
            conn.Open();
            DataSet ds = new DataSet();
            SqlCommand cmd = conn.CreateCommand();

            cmd.CommandText = "select LID 流水号,CID 卡号,MID 商家编号,RETURNMONEY 交易金额,RETURNTIME 交易时间 from CHJLB where LID='" + lsh + "'";
            
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(ds);
            dataGridView1.DataSource = ds.Tables[0];
        }


        //导入撤回记录表
        public void insert()
       {
            DateTime dt = DateTime.Now;
            string sqlse_SID = string.Format("insert into CHJLB values ('{0}','{1}','{2}','{3}','{4}')", cxLID, cxCID, cxMID, cxREMO, dt);
            SqlCommand cmdse_SID = new SqlCommand(sqlse_SID, conn);
            cmdse_SID.ExecuteScalar();
       }


        //查询撤回记录表
        public void select() 
        {
            string sql_sel2 = string.Format("Select LID 流水号,CID 卡号,MID 商家编号,RETURNMONEY 撤销金额,RETURNTIME 撤销时间 from CHJLB where LID = '{0}'", cxLID);
            SqlDataAdapter sda = new SqlDataAdapter(sql_sel2, conn);
            DataSet ds2 = new DataSet();
            sda.Fill(ds2);
            DataTable dt2 = ds2.Tables[0];
            dataGridView3.DataSource = dt2;
        }

        //更新卡信息表
        public void update() 
        {
            string sql_3 = string.Format("update KXXB set Money = Money + {0} where CID = '{1}'", cxREMO, cxCID);
            SqlCommand cmdsql_3 = new SqlCommand(sql_3, conn);
            cmdsql_3.ExecuteNonQuery();
        }


        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }
        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }
    }
}
