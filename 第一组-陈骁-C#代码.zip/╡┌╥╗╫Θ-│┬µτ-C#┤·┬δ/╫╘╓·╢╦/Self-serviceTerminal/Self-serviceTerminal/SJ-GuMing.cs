﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Self_serviceTerminal
{
    public partial class SJ_GuMing : Form
    {
        public SJ_GuMing()
        {
            InitializeComponent();
        }

        SqlConnection conn;

        private void button1_Click(object sender, EventArgs e)
        {
            conn = new SqlConnection(SQLHelper.connString);
            conn.Open();
            DateTime dt = DateTime.Now;
            string LSH = "LSM1" + dt.ToString("yyyyMMddHHmmss");
            string KH = textBox1.Text.Trim(); ;
            string SJBH = "M1";
            DateTime JYSJ = dt;

            string sql_se1 = string.Format("select * from KXXB where CID = '{0}' and Cstatus = '在用'", KH);
            SqlCommand cmdsql_se1 = new SqlCommand(sql_se1, conn);
            if (cmdsql_se1.ExecuteScalar() == null)
            {
                MessageBox.Show("您的卡号不存在或不可用！");
            }
            else if (maskedTextBox1.Text == "")
            {
                MessageBox.Show("请输入金额！");
            }
            else
            {
                double JYJE = Convert.ToDouble(maskedTextBox1.Text);
                string sql_1 = string.Format("insert into LSXXB values( '{0}','{1}','{2}',{3},'{4}')", LSH, KH, SJBH, JYJE, JYSJ);
                SqlCommand cmdsql_1 = new SqlCommand(sql_1, conn);
                cmdsql_1.ExecuteNonQuery();

                string sql_2 = string.Format("update KXXB set Money = Money - {0} where CID = '{1}'", JYJE, KH);
                SqlCommand cmdsql_2 = new SqlCommand(sql_2, conn);
                cmdsql_2.ExecuteNonQuery();

                MessageBox.Show("交易成功！");
            }
            conn.Close();
        }
    }
}