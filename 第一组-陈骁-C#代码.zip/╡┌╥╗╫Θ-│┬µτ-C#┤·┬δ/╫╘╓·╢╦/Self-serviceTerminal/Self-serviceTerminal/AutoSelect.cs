﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Self_serviceTerminal
{
    public partial class AutoSelect : Form
    {
        public AutoSelect()
        {
            InitializeComponent();
        }
        SqlConnection conn;
        DataSet ds1 = new DataSet();
        DataSet ds2 = new DataSet();
        DataSet ds3 = new DataSet();
        DataSet ds4 = new DataSet();
        DataView mydv = new DataView();
        DataView mydv2 = new DataView();
        DataView mydv3 = new DataView();
        DataView mydv4 = new DataView();
        SqlDataAdapter sda1 = null;
        int i = 0;

        private void button4_Click(object sender, EventArgs e)
        {
            conn = new SqlConnection(SQLHelper.connString);
            conn.Open();

            ds1.Clear();
            string KH = LForm2.CardID;
            string sql_se1 = string.Format("select CID 卡号,Money 余额 from KXXB where CID = '{0}'", LForm2.CardID);
            sda1 = new SqlDataAdapter(sql_se1, conn);
            sda1.Fill(ds1, "a");
            mydv = new DataView(ds1.Tables["a"]);
            dataGridView1.DataSource = ds1.Tables[0];
            
            conn.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            conn = new SqlConnection(SQLHelper.connString);
            conn.Open();

            ds2.Clear();
            string KH = LForm2.CardID;
            string sql_se1 = string.Format("select LID 流水号,CID 卡号,MID 商家编号,ExchangeMoney 交易金额,ExchangeTime 交易时间 from LSXXB where CID = '{0}'", LForm2.CardID);
            sda1 = new SqlDataAdapter(sql_se1, conn);
            sda1.Fill(ds2, "b");
            mydv2 = new DataView(ds2.Tables["b"]);
            dataGridView1.DataSource = ds2.Tables[0];
            
            conn.Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            conn = new SqlConnection(SQLHelper.connString);
            conn.Open();

            ds3.Clear();
            string KH = LForm2.CardID;
            string sql_se1 = string.Format("select LID 流水号,CID 卡号,MID 商家编号,ReturnMoney 撤销金额,ReturnTime 撤回时间 from CHJLB where CID = '{0}'", LForm2.CardID);
            sda1 = new SqlDataAdapter(sql_se1, conn);
            sda1.Fill(ds3, "c");
            mydv3 = new DataView(ds3.Tables["c"]);
            dataGridView1.DataSource = ds3.Tables[0];
            
            conn.Close();

        }

        private void button3_Click(object sender, EventArgs e)
        {
            conn = new SqlConnection(SQLHelper.connString);
            conn.Open();

            ds4.Clear();
            string KH = LForm2.CardID;
            string sql_se1 = string.Format("select DID 订单号,CID 卡号,ChargeMoney 充值金额,ChargeWay 充值方式, PayID 充值账号, PayTime 充值时间 from CZJLB where CID = '{0}'", LForm2.CardID);
            sda1 = new SqlDataAdapter(sql_se1, conn);
            sda1.Fill(ds4, "c");
            mydv4 = new DataView(ds4.Tables["c"]);
            dataGridView1.DataSource = ds4.Tables[0];

            conn.Close();

        }
    }
}
