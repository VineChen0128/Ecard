﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Ecard
{
    public partial class SelectRecord : UserControl
    {
        SqlConnection conn = null;
        DataSet ds = new DataSet();
        DataView mydv = new DataView();

        public SelectRecord()
        {
            InitializeComponent();
            conn = new SqlConnection(SQLHelper.connString);
        }
        

        private void button1_Click(object sender, EventArgs e)
        {
            conn.Open();

            SqlDataAdapter searchall = new SqlDataAdapter();
            searchall = new SqlDataAdapter("select * from sheetname", conn);
            searchall.Fill(ds, "a");
            mydv = new DataView(ds.Tables["a"]);
            dataGridView1.DataSource = ds.Tables[0];

            conn.Close();

        }

        private void button1_Click_1(object sender, EventArgs e)
        {

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
