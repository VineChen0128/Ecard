﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
namespace Ecard
{
    public partial class ManageState : UserControl
    {
        SqlConnection mycon = null;
        public static string WindowsFormsApplication2Num;
        private int errortime = 3;

        public ManageState()
        {
            InitializeComponent();
        }
        SqlConnection conn;
        DataSet ds = new DataSet();
        DataSet ds2 = new DataSet();
        DataSet ds3 = new DataSet();
        DataSet ds4 = new DataSet();
        DataView mydv = new DataView();
        SqlDataAdapter sda1 = null;
        int i = 0;
        int j = 0;

        public object A { get; private set; }

        private void 个人注销ToolStripMenuItem_Click(object sender, EventArgs e)
        {
        }

        private void 批量ToolStripMenuItem_Click(object sender, EventArgs e)
        {
         

        }

        private void tabPage1_Click(object sender, EventArgs e)
        {

        }

        private void tabControl1_SelectedIndexChanged(object sender, EventArgs e)
        {
        }

        private void button1_Click(object sender, EventArgs e)
        {
            ////查询------
            conn = new SqlConnection(SQLHelper.connString);
            conn.Open();
            //
            ds.Clear();
            string A = textBox1.Text.Trim();//把textBox1.Text所输入的内容当作一个值赋值给A

            string sql_1 = string.Format("select CID from KXXB where CID = '{0}'", A);
            SqlCommand cmdsql_1 = new SqlCommand(sql_1, conn);
            if (cmdsql_1.ExecuteScalar() == null)
            {
                MessageBox.Show("卡号不存在！");
            }
            else
            {
                string sql_2 = string.Format("select CID from KXXB where CID = '{0}' and Cstatus='在用'", A);
                SqlCommand cmdsql_2 = new SqlCommand(sql_2, conn);
                if (cmdsql_2.ExecuteScalar() != null)
                {
                    string sql_gashi = string.Format("update KXXB set Cstatus = '停用' where CID = '{0}'", A);
                    SqlCommand cmd = new SqlCommand(sql_gashi, conn);
                    cmd.ExecuteNonQuery();

                    string sql_CXgashi = string.Format("select CID 卡号,SIDORTIDORPID 学号或工号或编号,CSTATUS 卡状态,MONEY 余额,PTIME 失效时间 from KXXB where CID = '{0}'", A);
                    sda1 = new SqlDataAdapter(sql_CXgashi, conn);
                    sda1.Fill(ds, "a");
                    mydv = new DataView(ds.Tables["a"]);
                    dataGridView1.DataSource = ds.Tables[0];
                    
                }
                else
                {
                    MessageBox.Show("该卡已停用或已注销！");
                    //if(i == 0 && j == 0)
                    //{ 
                    //    dataGridView1.DataSource = ds.Tables[0];
                    //    j = 1;
                    //}
                    //else
                    //    dataGridView1.DataSource = ds.Tables[j];
 
            }
            
               
            }
            conn.Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {

            
        }

        private void button2_Click_1(object sender, EventArgs e)
        {
            conn = new SqlConnection(SQLHelper.connString);
            conn.Open();
            ds2.Clear();
            string A = textBox1.Text.Trim();

            string sql_3 = string.Format("select CID from KXXB where CID = '{0}'", A);
            SqlCommand cmdsql_2 = new SqlCommand(sql_3, conn);
            if (cmdsql_2.ExecuteScalar() == null)
            {
                MessageBox.Show("卡号不存在！");
            }
            else 
            {
                string sql_4 = string.Format("select CID from KXXB where CID = '{0}' and Cstatus='停用'", A);
                SqlCommand cmdsql_3 = new SqlCommand(sql_4, conn);
                //string sql_5 = string.Format("select CID from KXXB where CID = '{0}' and Cstatus='注销'", A);
                //SqlCommand cmdsql_4 = new SqlCommand(sql_5, conn);
                if (cmdsql_3.ExecuteScalar() != null)
                {
                    string sql_gashi = string.Format("update KXXB set Cstatus = '在用' where CID = '{0}'", A);
                    SqlCommand cmd = new SqlCommand(sql_gashi, conn);
                    cmd.ExecuteNonQuery();

                    string sql_CXgashi = string.Format("select CID 卡号,SIDORTIDORPID 学号或工号或编号,CSTATUS 卡状态,MONEY 余额,PTIME 失效时间 from KXXB where CID = '{0}'", A);
                    sda1 = new SqlDataAdapter(sql_CXgashi, conn);
                    sda1.Fill(ds2, "b");
                    mydv = new DataView(ds2.Tables["b"]);
                    //if (i == 0 && j == 0)
                    //{
                    //    dataGridView1.DataSource = ds.Tables[0];
                    //    j = 1;
                    //}
                    //else
                    //    dataGridView1.DataSource = ds.Tables[j];
                    dataGridView1.DataSource = ds2.Tables[0];
                }
                else
                {
                    MessageBox.Show("该卡已激活或已注销！");
                }
 
            }
            conn.Close();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            conn = new SqlConnection(SQLHelper.connString);
            conn.Open();
            //
            ds3.Clear();
            string A = textBox2.Text;//把textBox1.Text所输入的内容当作一个值赋值给A

            string sql_1 = string.Format("select CID from KXXB where CID = '{0}'", A);
            SqlCommand cmdsql_1 = new SqlCommand(sql_1, conn);
            string sql_2 = string.Format("select CID from KXXB where CID = '{0}' and Cstatus='注销'", A);
            SqlCommand cmdsql_2 = new SqlCommand(sql_2, conn);
            if (cmdsql_1.ExecuteScalar() == null || cmdsql_2.ExecuteScalar() != null)
            {
                MessageBox.Show("卡号不存在或已注销");
            }
            else
            {
                //string sql_tuiqian = string.Format("select Money from KXXB where CID = '{0}'", A);
                //SqlCommand cmdsql_tuiqian = new SqlCommand(sql_tuiqian, conn);
                //string tuiqian = string.Format("需退还人名币{0}元", cmdsql_tuiqian.ExecuteScalar());
                //MessageBox.Show(tuiqian);

                string sql_gashi = string.Format("update KXXB set Cstatus = '注销' where CID = '{0}'", A);
                SqlCommand cmd = new SqlCommand(sql_gashi, conn);
                cmd.ExecuteNonQuery();

                string sql_CXgashi = string.Format("select CID 卡号,SIDORTIDORPID 学号或工号或编号,CSTATUS 卡状态,MONEY 余额,PTIME 失效时间 from KXXB where CID = '{0}'", A);
                ds3.Clear();
                sda1 = new SqlDataAdapter(sql_CXgashi, conn);
                sda1.Fill(ds3, "a");
                mydv = new DataView(ds3.Tables["a"]);
                dataGridView1.DataSource = ds3.Tables[0];
                MessageBox.Show("注销成功");
                
            }
            conn.Close();
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void comboBox1_DropDown(object sender, EventArgs e)
        {
            //comboBox1.Items.Clear();
            //comboBox1.Text = "";
            conn = new SqlConnection(SQLHelper.connString);
            conn.Open();

           // string a = comboBox7.Text;
            string sql = string.Format("select distinct Sclass from XSXXB");
            SqlCommand cmd;
            (sender as ComboBox).Items.Clear();
            cmd = new SqlCommand(sql, conn);
            SqlDataReader reader = cmd.ExecuteReader();
            while (reader.Read())
                (sender as ComboBox).Items.Add(reader.GetString(0));
            reader.Close();

            conn.Close();
        }

        private void tabPage3_Click(object sender, EventArgs e)
        {

        }

        private void ManageState_Load(object sender, EventArgs e)
        {
            

        }

        private void button4_Click(object sender, EventArgs e)
        {
            if (comboBox1.Text == "")
                MessageBox.Show("请选择需要批量注销的班级！");
            else
            {
                conn = new SqlConnection(SQLHelper.connString);
                conn.Open();

                string sql_plzx = string.Format("update a set a.cstatus = '注销' from KXXB a,XSXXB b where a.SIDorTIDorPID = b.SID and b.Sclass = '{0}'", comboBox1.Text);
                SqlCommand cmdsql_plzx = new SqlCommand(sql_plzx, conn);
                cmdsql_plzx.ExecuteNonQuery();
                
                string sql_cxplzx = string.Format("select KXXB.CID 卡号,KXXB.SIDorTIDorPID 学号,XSXXB.Sname 姓名,XSXXB.Smajor 专业,XSXXB.Sclass 班级,KXXB.Money 余额,KXXB.Cstatus 卡状态 from KXXB join XSXXB on KXXB.SIDorTIDorPID = XSXXB.SID where XSXXB.Sclass = '{0}'", comboBox1.Text);
                
                sda1 = new SqlDataAdapter(sql_cxplzx, conn);
                sda1.Fill(ds4, "a");
                mydv = new DataView(ds4.Tables["a"]);
                dataGridView1.DataSource = ds4.Tables[0];
                MessageBox.Show("注销成功");
                conn.Close();
            }
        }

        //private void button5_Click(object sender, EventArgs e)
        //{
        //    conn = new SqlConnection(SQLHelper.connString);
        //    conn.Open();

        //    string sql_plzx = string.Format("update a set a.Money = 0 from KXXB a,XSXXB b where a.SIDorTIDorPID = b.SID and b.Sclass = '{0}'", comboBox1.Text);
        //    SqlCommand cmdsql_plzx = new SqlCommand(sql_plzx, conn);
        //    cmdsql_plzx.ExecuteNonQuery();
        //    MessageBox.Show("余额已清零");
        //    conn.Close();
        //}
    }
}