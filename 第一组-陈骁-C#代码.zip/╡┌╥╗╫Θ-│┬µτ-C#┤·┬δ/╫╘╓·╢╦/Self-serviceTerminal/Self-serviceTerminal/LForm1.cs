﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Self_serviceTerminal
{
    public partial class LForm1 : Form
    {
        public LForm1()
        {
            InitializeComponent();
        }
        SqlConnection conn = null;
        public static string CardID;

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            if (textBox1.Text == "")
                MessageBox.Show("请输入编号", "警告", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            else if (textBox2.Text == "")
                MessageBox.Show("请输入密码", "警告", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            else
            {
                string usernum = textBox1.Text.Trim();
                string pw = textBox2.Text.Trim();

                conn = new SqlConnection(SQLHelper.connString);
                conn.Open();

                string s1 = "select * from KXXB where SIDorTIDorPID='" + usernum + "' and CID='" + pw + "'";
                SqlCommand mycom = new SqlCommand(s1, conn);
                if (mycom.ExecuteScalar() == null)
                {
                    MessageBox.Show("编号或卡号错误！");
                }
                else
                {
                    CardID = pw;
                    AutoRecharge AR = new AutoRecharge();
                    //AR.Show();
                    AR.ShowDialog();
                    //AR.BringToFront();
                    this.Close();
                    
                }
                conn.Close();

                
            }
        }

        private void LForm1_Load(object sender, EventArgs e)
        {

        }
    }
}
