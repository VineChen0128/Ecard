﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Ecard
{
    public partial class AddStaff : UserControl
    {
        public AddStaff()
        {
            InitializeComponent();
        }
        SqlConnection conn;

        private void button1_Click(object sender, EventArgs e)
        {
            conn = new SqlConnection(SQLHelper.connString);
            conn.Open();

            string a = textBox1.Text.Trim();
            string b = textBox2.Text.Trim();
            string c = textBox3.Text.Trim();
            int d = comboBox1.SelectedIndex + 1;
            string sqlse_SID = string.Format("insert into GLYB (ID ,Password ,Glname ,QX ) values ( '{0}','{1}','{2}',{3})", a, b, c, d);
            SqlCommand cmdse_SID = new SqlCommand(sqlse_SID, conn);
            cmdse_SID.ExecuteScalar();

            conn.Close();

        }

        private void button2_Click(object sender, EventArgs e)
        {
            conn = new SqlConnection(SQLHelper.connString);
            conn.Open();
            string a = textBox4.Text.Trim();
            int b = comboBox2.SelectedIndex + 1;

            string sqlse_SID = string.Format("update  GLYB set QX = '{0}' where ID= '{1}'", a, b);
            SqlCommand cmdse_SID = new SqlCommand(sqlse_SID, conn);
            cmdse_SID.ExecuteScalar();
            conn.Close();
        }

        private void AddStaff_Load(object sender, EventArgs e)
        {
            comboBox1.SelectedIndex = 0;
            comboBox2.SelectedIndex = 0;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            conn = new SqlConnection(SQLHelper.connString);
            conn.Open();
            string a = textBox5.Text.Trim();
            string sqlse_SID = string.Format("update  GLYB set Password = 000000 where ID= '{0}'", a);
            SqlCommand cmdse_SID = new SqlCommand(sqlse_SID, conn);
            cmdse_SID.ExecuteScalar();
            conn.Close();
        }
    }
}
