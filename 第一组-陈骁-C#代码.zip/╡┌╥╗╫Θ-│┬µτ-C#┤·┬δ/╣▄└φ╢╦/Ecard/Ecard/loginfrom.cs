﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Ecard
{
    public partial class loginfrom : Form
    {
        public loginfrom()
        {
            InitializeComponent();
        }
        SqlConnection conn = null;
        public static string WindowsFormsApplication2Num;
        private int errortime = 3;

        private void Form1_Load(object sender, EventArgs e)
        {
            Random yzm = new Random();
            label4.Text = Convert.ToString(yzm.Next(1000, 9999));



        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (textBox1.Text == "")
                MessageBox.Show("请输入员工编号", "警告", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            else if (textBox2.Text == "")
                MessageBox.Show("请输入密码", "警告", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            else
            {
                string usernum = textBox1.Text.Trim();
                string pw = textBox2.Text.Trim();

                conn = new SqlConnection(SQLHelper.connString);
                conn.Open();

                string s1 = "select * from GLYB where ID='" + usernum + "' and Password='" + pw + "'";
                SqlCommand mycom = new SqlCommand(s1, conn);
                mycom.ExecuteScalar();
                if (mycom.ExecuteScalar() == null)
                {
                    MessageBox.Show("账号或密码错误！");
                    Random yzm = new Random();
                    label4.Text = Convert.ToString(yzm.Next(1000, 9999));
                }
                else
                {
                    string s2 = "select Glname from GLYB where ID='" + usernum + "'";
                    SqlCommand mycom2 = new SqlCommand(s2, conn);
                    mycom2.ExecuteScalar();
                    string username = Convert.ToString(mycom2.ExecuteScalar());
                    MainFrom.username = username;
                    //ManagementSystemOfGJJ.dlr = username;
                    MessageBox.Show("欢迎您！" + username + "");

                    string s3 = "select QX from GLYB where ID='" + usernum + "'";
                    SqlCommand mycom3 = new SqlCommand(s3, conn);
                    mycom3.ExecuteScalar();
                    MainFrom.TheUserPermission = Convert.ToInt32(mycom3.ExecuteScalar());

                    //string s4 = "select BMBH from DLB where YGBH='" + usernum + "'";
                    //SqlCommand mycom4 = new SqlCommand(s4, conn);
                    //mycom4.ExecuteScalar();
                    //ManagementSystemOfGJJ.TheUserDepartment = Convert.ToInt32(mycom4.ExecuteScalar());

                    DialogResult = DialogResult.OK;


                    string s4 = string.Format("update KXXB set Cstatus = '停用' where Ptime < getdate() and Cstatus = '在用'");
                    SqlCommand coms4 = new SqlCommand(s4, conn);
                    coms4.ExecuteScalar();


                    

                }
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
