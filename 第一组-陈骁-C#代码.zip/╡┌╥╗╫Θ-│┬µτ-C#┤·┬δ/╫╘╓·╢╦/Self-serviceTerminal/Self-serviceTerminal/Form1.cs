﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Self_serviceTerminal
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        SqlConnection conn = null;

        private void button3_Click(object sender, EventArgs e)
        {
            PayForm PF = new PayForm();
            PF.ShowDialog();


        }

        private void button1_Click(object sender, EventArgs e)
        {
            LForm1 lf1 = new LForm1();
            lf1.ShowDialog();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            LForm2 lf2 = new LForm2();
            lf2.ShowDialog();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            LForm3 lf3 = new LForm3();
            lf3.ShowDialog();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            SqlConnection conn = null;
            conn = new SqlConnection(SQLHelper.connString);
            conn.Open();
            string s4 = string.Format("update KXXB set Cstatus = '停用' where Ptime < getdate() and Cstatus = '在用'");
            SqlCommand coms4 = new SqlCommand(s4, conn);
            coms4.ExecuteScalar();
            conn.Close();
        }

        private void button5_Click(object sender, EventArgs e)
        {

        }

        private void button5_Click_1(object sender, EventArgs e)
        {
            //conn = new SqlConnection(SQLHelper.connString);
            //conn.Open();
            ////string A = textBox1.Text.Trim();

            //string sql_3 = string.Format("select CID from KXXB where CID = '{0}'", A);
            //SqlCommand cmdsql_2 = new SqlCommand(sql_3, conn);
            //if (cmdsql_2.ExecuteScalar() == null)
            //{
            //    MessageBox.Show("卡号不存在！");
            //}
            //else
            //{
            //    string sql_4 = string.Format("select CID from KXXB where CID = '{0}' and Cstatus='在用'", A);
            //    SqlCommand cmdsql_3 = new SqlCommand(sql_4, conn);
            //    if (cmdsql_3.ExecuteScalar() != null)
            //    {
            //        MessageBox.Show("该卡已激活！");
            //    }
            //    else
            //    {
            //        string sql_gashi = string.Format("update KXXB set Cstatus = '在用' where CID = '{0}'", A);
            //        SqlCommand cmd = new SqlCommand(sql_gashi, conn);
            //        cmd.ExecuteNonQuery();
            //    }
            //}
        }

        private void button5_Click_2(object sender, EventArgs e)
        {
            LForm5 l5 = new LForm5();
            l5.ShowDialog();
            //conn = new SqlConnection(SQLHelper.connString);
            //conn.Open();

            //string sql_se1 = string.Format("select CID FROM KXXN where SIDORTIDORPID = '{0}' and Cstatus = '在用'");
            //SqlCommand cmdsql_se1 = new SqlCommand(sql_se1,conn);
            //string a = "您当前的卡号为：" + Convert.ToString(cmdsql_se1.ExecuteScalar());
            //MessageBox.Show(a);
                        

            //conn.Close();
        }
    }
}
