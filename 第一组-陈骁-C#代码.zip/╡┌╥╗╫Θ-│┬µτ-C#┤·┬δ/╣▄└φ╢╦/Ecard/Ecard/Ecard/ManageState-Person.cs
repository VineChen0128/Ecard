﻿using System;using System.Collections.Generic;using System.ComponentModel;using System.Data;using System.Drawing;using System.Linq;using System.Text;using System.Threading.Tasks;using System.Windows.Forms;using System.Data.SqlClient;

namespace Ecard
{
    public partial class ManageState_Person : UserControl
    {
        public ManageState_Person()
        {
            InitializeComponent();
        }
        SqlConnection conn;        DataSet ds = new DataSet();        DataView mydv = new DataView();        SqlDataAdapter sda1 = null;
        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            conn = new SqlConnection(SQLHelper.connString);            conn.Open();
            //
            string A = textBox1.Text;//把textBox1.Text所输入的内容当作一个值赋值给A

            string sql_1 = string.Format("select CID from KXXB where CID = '{0}'", A);            SqlCommand cmdsql_1 = new SqlCommand(sql_1, conn);            string sql_2 = string.Format("select CID from KXXB where CID = '{0}' and Cstatus='注销'", A);            SqlCommand cmdsql_2 = new SqlCommand(sql_2, conn);            if (cmdsql_1.ExecuteScalar() == null || cmdsql_2.ExecuteScalar() != null)
            {                MessageBox.Show("ERROR");            }            else            {                string sql_gashi = string.Format("update KXXB set Cstatus = '注销' where CID = '{0}'", A);                SqlCommand cmd = new SqlCommand(sql_gashi, conn);                cmd.ExecuteNonQuery();                string sql_CXgashi = string.Format("select * from KXXB where CID = '{0}'", A);                sda1 = new SqlDataAdapter(sql_CXgashi, conn);                sda1.Fill(ds, "a");                mydv = new DataView(ds.Tables["a"]);                {
                    MessageBox.Show("注销成功");
                }            }            conn.Close();        }
    }
}

