﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Self_serviceTerminal
{
    public partial class LForm5 : Form
    {
        public LForm5()
        {
            InitializeComponent();
        }
        SqlConnection conn = null;

        private void button1_Click(object sender, EventArgs e)
        {
            conn = new SqlConnection(SQLHelper.connString);
            conn.Open();

            string sql_se1 = string.Format("select CID FROM KXXB where SIDORTIDORPID = '{0}' and Cstatus = '在用'",textBox1.Text.Trim());
            SqlCommand cmdsql_se1 = new SqlCommand(sql_se1, conn);
            string a = "您当前的卡号为：" + Convert.ToString(cmdsql_se1.ExecuteScalar());
            if (cmdsql_se1.ExecuteScalar() == null)
            {
                MessageBox.Show("您输入的学号/工号/编号不存在");
            }
            else
                MessageBox.Show(a);


            conn.Close();
        }
    }
}
