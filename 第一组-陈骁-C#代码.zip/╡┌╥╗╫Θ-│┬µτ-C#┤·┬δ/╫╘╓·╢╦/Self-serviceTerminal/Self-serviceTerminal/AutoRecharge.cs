﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Self_serviceTerminal
{
    public partial class AutoRecharge : Form
    {
        public AutoRecharge()
        {
            InitializeComponent();
        }
        SqlConnection conn = null;

        private void AutoRecharge_Load(object sender, EventArgs e)
        {
            comboBox1.SelectedIndex = 0;
            textBox1.Visible = false;
            textBox2.Visible = false;
            label3.Visible = false;
            label4.Visible = false;
            
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //string sql_cxzt

            //充值，加充值记录，加余额，扣支付宝余额
            conn = new SqlConnection(SQLHelper.connString);
            conn.Open();

            string PayID = textBox1.Text.Trim();
            
            DateTime dt = DateTime.Now;
            string DID = "DH" + dt.ToString("yyyyMMddHHmmss");
            string CID = LForm1.CardID; ;
            
            int ChargeWay = 1;
            int ChargeMoney;
            if (comboBox1.SelectedIndex == 0)
            {
                if (textBox3.Text == "")
                {
                    MessageBox.Show("充值失败，请输入完整！");
                }
                else
                {
                    try
                    { 
                        ChargeMoney = Convert.ToInt32(textBox3.Text);
                        ChargeWay = 0;
                        PayID = null;
                        DateTime PayTime = dt;
                        string sql_2 = string.Format("insert into CZJLB values( '{0}','{1}',{2},{3},'{4}','{5}')", DID, CID, ChargeMoney, ChargeWay, PayID, PayTime);
                        SqlCommand cmdsql_2 = new SqlCommand(sql_2, conn);
                        cmdsql_2.ExecuteNonQuery();
                        MessageBox.Show("生成充值记录完成");
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("请将价格输入完整，包括小数！");
                    }
                }
            }
            else if (textBox3.Text == "" || textBox1.Text == "" || textBox2.Text == "")
            {
                MessageBox.Show("充值失败，请输入完整！");
            }
            else
            {
                try
                { 
                    ChargeMoney = Convert.ToInt32(textBox3.Text);
                    //if (comboBox1.SelectedIndex != 0)
                    //{
                    //    ChargeWay = 0;
                    //    PayID = null;
                    //    DateTime PayTime = dt;
                    //    string sql_2 = string.Format("insert into CZJLB values( '{0}','{1}',{2},{3},'{4}','{5}')", DID, CID, ChargeMoney, ChargeWay, PayID, PayTime);
                    //    SqlCommand cmdsql_2 = new SqlCommand(sql_2, conn);
                    //    cmdsql_2.ExecuteNonQuery();
                    //    MessageBox.Show("生成充值记录完成");
                    //}
                    //else
                    //{

                        string sql_sel = string.Format("select * from ZFBB where PayID = '{0}' and Paypw = '{1}'", textBox1.Text.Trim(), textBox2.Text.Trim());
                        SqlCommand cmdsql_sel = new SqlCommand(sql_sel, conn);
                        if (cmdsql_sel.ExecuteScalar() == null)
                        {
                            MessageBox.Show("支付宝账号或密码错误！");
                        }
                        else
                        {
                            string sql_sel2 = string.Format("select PayMoney from ZFBB where PayID = '{0}' and Paypw = '{1}'", textBox1.Text.Trim(), textBox2.Text.Trim());
                            SqlCommand cmdsql_sel2 = new SqlCommand(sql_sel2, conn);
                            if (Convert.ToInt32(cmdsql_sel2.ExecuteScalar()) < Convert.ToInt32(textBox3.Text))
                            {
                                MessageBox.Show("余额不足！");
                            }
                            DateTime PayTime = dt;
                            string sql_2 = string.Format("insert into CZJLB values( '{0}','{1}',{2},{3},'{4}','{5}')", DID, CID, ChargeMoney, ChargeWay, PayID, PayTime);
                            SqlCommand cmdsql_2 = new SqlCommand(sql_2, conn);
                            cmdsql_2.ExecuteNonQuery();
                            string sql_3 = string.Format("update ZFBB set PayMoney = PayMoney - {0} where PayID = '{1}'", ChargeMoney, PayID);
                            SqlCommand cmdsql_3 = new SqlCommand(sql_3, conn);
                            cmdsql_3.ExecuteNonQuery();
                            MessageBox.Show("生成充值记录完成");
                        }
                    //}
                    string sql_4 = string.Format("update KXXB set Money = Money + {0} where CID = '{1}'", ChargeMoney, LForm1.CardID);
                    SqlCommand cmdsql_4 = new SqlCommand(sql_4, conn);
                    cmdsql_4.ExecuteNonQuery();
                    conn.Close();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("请将价格输入完整，包括小数！");
                }

                
                

                //try
                //{ 
                //    ChargeMoney = Convert.ToDouble(maskedTextBox1.Text);
                //    string sql_sel = string.Format("select * from ZFBB where PayID = '{0}' and Paypw = '{1}'", textBox1.Text.Trim(), textBox2.Text.Trim());
                //    SqlCommand cmdsql_sel = new SqlCommand(sql_sel, conn);
                //    if (cmdsql_sel.ExecuteScalar() == null)
                //    {
                //        MessageBox.Show("支付宝账号或密码错误！");
                //    }
                //    else
                //    {
                //        string sql_sel2 = string.Format("select PayMoney from ZFBB where PayID = '{0}' and Paypw = '{1}'", textBox1.Text.Trim(), textBox2.Text.Trim());
                //        SqlCommand cmdsql_sel2 = new SqlCommand(sql_sel2, conn);
                //        if (Convert.ToDouble(cmdsql_sel2.ExecuteScalar()) < Convert.ToDouble(maskedTextBox1.Text))
                //        {
                //            MessageBox.Show("余额不足！");
                //        }
                //        else
                //        {
                //            if (comboBox1.SelectedIndex != 0)
                //            {
                //                ChargeWay = 0;
                //                PayID = null;
                //                DateTime PayTime = dt;
                //                string sql_2 = string.Format("insert into CZJLB values( '{0}','{1}',{2},{3},'{4}','{5}')", DID, CID, ChargeMoney, ChargeWay, PayID, PayTime);
                //                SqlCommand cmdsql_2 = new SqlCommand(sql_2, conn);
                //                cmdsql_2.ExecuteNonQuery();
                //                MessageBox.Show("生成充值记录完成");
                //            }
                //            else
                //            {
                //                DateTime PayTime = dt;
                //                string sql_2 = string.Format("insert into CZJLB values( '{0}','{1}',{2},{3},'{4}','{5}')", DID, CID, ChargeMoney, ChargeWay, PayID, PayTime);
                //                SqlCommand cmdsql_2 = new SqlCommand(sql_2, conn);
                //                cmdsql_2.ExecuteNonQuery();
                //                string sql_3 = string.Format("update ZFBB set PayMoney = PayMoney - {0} where PayID = '{1}'", ChargeMoney, PayID);
                //                SqlCommand cmdsql_3 = new SqlCommand(sql_3, conn);
                //                cmdsql_3.ExecuteNonQuery();
                //                MessageBox.Show("生成充值记录完成");
                //            }
                //            string sql_4 = string.Format("update KXXB set Money = Money + {0} where CID = '{1}'", ChargeMoney, LForm1.CardID);
                //            SqlCommand cmdsql_4 = new SqlCommand(sql_4, conn);
                //            cmdsql_4.ExecuteNonQuery();
                //            conn.Close();
                //        }
                //    }
                //}
                //catch (Exception ex)
                //{
                //    MessageBox.Show("请将价格输入完整，包括小数！");
                //}
                
            }
            textBox3.Text = "";
            textBox1.Text = "";
            textBox2.Text = "";
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (comboBox1.SelectedIndex != 0)
            {
                textBox1.Visible = true;
                textBox2.Visible = true;
                label3.Visible = true;
                label4.Visible = true;
            }
            else 
            {
                textBox1.Visible = false;
                textBox2.Visible = false;
                label3.Visible = false;
                label4.Visible = false;
            }

        }

        private void textBox3_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar != '\b')
            {
                if ((e.KeyChar < '0') || (e.KeyChar > '9'))
                {
                    e.Handled = true;
                }
            }
        }
    }
}
