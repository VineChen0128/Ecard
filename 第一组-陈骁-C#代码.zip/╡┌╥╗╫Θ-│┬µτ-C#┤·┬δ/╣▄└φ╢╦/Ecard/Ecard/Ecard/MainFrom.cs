﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Ecard
{
    public partial class MainFrom : Form
    {
        RegisterFreshman RF = new RegisterFreshman();
        SelectRecord SR = new SelectRecord();
        ManageState MS = new ManageState();
        TakeOutMoney TOM = new TakeOutMoney();
        DistributeSubsidy DS = new DistributeSubsidy();
        ChargeMoney CM = new ChargeMoney();
        

        public MainFrom()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            button1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
        }

        private void 新生信息导入ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            
        }

        private void 一卡通账户添加ToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void 系统管理员界面ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            
        }

        private void menuStrip1_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            SR.Visible = false;
            MS.Visible = false;
            TOM.Visible = false;
            DS.Visible = false;
            CM.Visible = false;
            RF.Visible = true;
            RF.Top = 225;
            RF.Left = 5;
            RF.Parent = this;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            RF.Visible = false;
            MS.Visible = false;
            TOM.Visible = false;
            DS.Visible = false;
            CM.Visible = false;
            SR.Visible = true;
            SR.Top = 225;
            SR.Left = 5;
            SR.Parent = this;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            RF.Visible = false;
            SR.Visible = false;
            TOM.Visible = false;
            DS.Visible = false;
            CM.Visible = false;
            MS.Visible = true;
            MS.Top = 225;
            MS.Left = 5;
            MS.Parent = this;

        }

        private void button4_Click(object sender, EventArgs e)
        {
            RF.Visible = false;
            SR.Visible = false;
            MS.Visible = false;
            DS.Visible = false;
            CM.Visible = false;
            TOM.Visible = true;
            TOM.Top = 225;
            TOM.Left = 5;
            TOM.Parent = this;

        }

        private void button6_Click(object sender, EventArgs e)
        {
            RF.Visible = false;
            SR.Visible = false;
            MS.Visible = false;
            TOM.Visible = false;
            CM.Visible = false;
            DS.Visible = true;
            DS.Top = 225;
            DS.Left = 5;
            DS.Parent = this;
        }

        private void button5_Click(object sender, EventArgs e)
        {
            RF.Visible = false;
            SR.Visible = false;
            MS.Visible = false;
            TOM.Visible = false;
            DS.Visible = false;
            CM.Visible = true;
            CM.Top = 225;
            CM.Left = 5;
            CM.Parent = this;
        }
    }
}
