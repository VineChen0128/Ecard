﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Data.OleDb;

namespace Ecard
{
    public partial class RegisterFreshman : UserControl
    {
        public RegisterFreshman()
        {
            InitializeComponent();
        }

        DataTable dt = new DataTable();
        SqlConnection conn;
        DataSet ds = new DataSet();
        DataSet ds2 = new DataSet();
        DataView mydv = new DataView();
        SqlDataAdapter sda1 = null;
        int xh = 10001;
        string oldCID;
        string oldSTPID;
        private void bind(string fileName)
        {
            try 
            {
                string strConn = "Provider=Microsoft.Ace.OleDb.12.0;" +
                 "Data Source=" + fileName + ";" +
                 "Extended Properties='Excel 8.0; HDR=Yes; IMEX=1'";
                OleDbDataAdapter da = new OleDbDataAdapter("SELECT *  FROM [sheet1$]", strConn);
                DataSet ds = new DataSet();
                try
                {
                    da.Fill(ds);
                    dt = ds.Tables[0];
                    this.dataGridView1.DataSource = dt;
                }
                catch (Exception ex)
                {
                    MessageBox.Show("操作失败！选择文件类型不是EXCEL表格或表格table命名不正确" + ex.ToString());
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("请选择正确格式文件！" + ex.ToString());
            }
        }

        private void bind2(string fileName)
        {
            try
            {
                string strConn = "Provider=Microsoft.Ace.OleDb.12.0;" +
                 "Data Source=" + fileName + ";" +
                 "Extended Properties='Excel 8.0; HDR=Yes; IMEX=1'";
                OleDbDataAdapter da2 = new OleDbDataAdapter("SELECT *  FROM [sheet1$]", strConn);
                DataSet ds2 = new DataSet();
                try
                {
                    da2.Fill(ds2);
                    dt = ds2.Tables[0];
                    this.dataGridView3.DataSource = dt;
                }
                catch (Exception ex)
                {
                    MessageBox.Show("操作失败！" + ex.ToString());
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("请选择正确格式文件！" + ex.ToString());
            }
        }



        private void insertToSql(DataRow dr)
        {
            try
            {
                string a = dr["学号"].ToString();
                string b = dr["姓名"].ToString();
                string c = dr["专业"].ToString();
                string d = dr["班级"].ToString();
                string sql = "insert into xsxxbtest values('" + a + "','" + b + "','" + c + "','" + d + "')";
                //string sql = "insert into sheetname values('a','b','c','d')";
                //XSXXB
                SqlCommand cmd = new SqlCommand(sql, this.conn);
                cmd.ExecuteNonQuery();

            }
            catch (Exception ex)
            {
                MessageBox.Show("操作失败！EXCEL表格格式错误，或学生信息重复！" + ex.ToString());
            }
            
        }

        private void insertToSql_KH(DataRow dr)
        {
            DateTime dt = DateTime.Now;
            string y = dt.ToString("yyyyMMddhhmmss");
            Random rd = new Random();
            string b = dr["学号"].ToString();
            string c = "在用";
            double d = 0.00;
            string e = dt.AddDays(1460).ToString();
            //int i = 1; i++;
            string a = "C" + y + Convert.ToString(xh);
            string sql_1 = string.Format("insert into KXXB (CID ,SIDorTIDorPID ,Cstatus ,Money ,Ptime ) values ('{0}','{1}','{2}',{3},'{4}')", a, b, c, d, e);
            SqlCommand cmdsql_1 = new SqlCommand(sql_1, conn);
            cmdsql_1.ExecuteNonQuery();
        }

        private void insertToSql_LSRY(DataRow dr)
        {
            DateTime dt = DateTime.Now;
            dt.AddDays(Convert.ToInt32(numericUpDown2.Value));
            string c = Convert.ToString(dt.AddDays(Convert.ToInt32(numericUpDown2.Value)));
            string a = dr["编号"].ToString();
            string b = dr["姓名"].ToString();
            try
            {
                string sql = "insert into LSRYB values('" + a + "','" + b + "','" + c + "')";
                SqlCommand cmd = new SqlCommand(sql, this.conn);
                cmd.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }

        private void insertToSql_LSRY2(DataRow dr)
        {
            DateTime dt = DateTime.Now;
            string y = dt.ToString("yyyyMMddhhmmss");
            Random rd = new Random();

            string b = dr["编号"].ToString();
            string c = "在用";
            double d = 0.00;
            string e = Convert.ToString(dt.AddDays(Convert.ToInt32(numericUpDown2.Value)));
            //int i = 1; i++;
            string a = "L" + y + Convert.ToString(xh);
            string sql_1 = string.Format("insert into KXXB (CID ,SIDorTIDorPID ,Cstatus ,Money ,Ptime ) values ('{0}','{1}','{2}',{3},'{4}')", a, b, c, d, e);
            SqlCommand cmdsql_1 = new SqlCommand(sql_1, conn);
            cmdsql_1.ExecuteNonQuery();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                System.Windows.Forms.OpenFileDialog fd = new OpenFileDialog();
                if (fd.ShowDialog() == DialogResult.OK)
                {
                    string fileName = fd.FileName;
                    textBox1.Text = fileName;
                    bind(fileName);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
            
        }

        private void button2_Click(object sender, EventArgs e)
        {
            conn = new SqlConnection(SQLHelper.connString);
            conn.Open();
            try
            {
                if (dataGridView1.Rows.Count > 0)
                {
                    DataRow dr = null;
                    for (int i = 0; i < dt.Rows.Count; i++)
                    {
                        dr = dt.Rows[i];
                        insertToSql(dr);
                        insertToSql_KH(dr);
                        xh++;
                    }
                    conn.Close();
                    MessageBox.Show("导入成功！");
                }
                else
                {
                    MessageBox.Show("没有数据！");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
            

        }

        private void tabPage1_Click(object sender, EventArgs e)
        {

        }

        private void tabControl1_Click(object sender, EventArgs e)
        {
            dt.Clear();
            textBox1.Text = "";
        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void RegisterFreshman_Load(object sender, EventArgs e)
        {
            comboBox1.SelectedIndex = 0;
        }

        private void label7_Click(object sender, EventArgs e)
        {

        }

        private void button7_Click(object sender, EventArgs e)
        {
            SqlConnection connOpen = new SqlConnection(SQLHelper.connString);
            connOpen.Open();

            DateTime dt = DateTime.Now;
            string y = dt.ToString("yyyyMMddhhmmss");
            Random rd = new Random();

            SqlCommand cmd = new SqlCommand();
            cmd.Connection = connOpen;
            string a = textBox6.Text.Trim();
            string b = textBox7.Text.Trim();
            dt.AddDays(Convert.ToInt32(numericUpDown1.Value));
            string c = Convert.ToString(dt.AddDays(Convert.ToInt32(numericUpDown1.Value)));
            string d = "L" + y + Convert.ToString(xh);
            string sql_1 = string.Format("insert into LSRYB values('{0}','{1}','{2}')", b, a, c);
            string sql = string.Format("insert into KXXB values('{0}','{1}','在用',0,'{2}')", a, b,c);
            SqlCommand sqlcmd_1 = new SqlCommand(sql_1, connOpen);
            SqlCommand sqlcmd = new SqlCommand(sql, connOpen);
            sqlcmd_1.ExecuteNonQuery();
            sqlcmd.ExecuteNonQuery();

            connOpen.Close();
            connOpen.Dispose();
            MessageBox.Show("录入成功！");
        }

        private void button4_Click(object sender, EventArgs e)
        {
            System.Windows.Forms.OpenFileDialog fd = new OpenFileDialog();
            if (fd.ShowDialog() == DialogResult.OK)
            {
                string fileName = fd.FileName;
                textBox5.Text = fileName;
                bind2(fileName);
            }
        }

        private void button6_Click(object sender, EventArgs e)
        {
            conn = new SqlConnection(SQLHelper.connString);
            conn.Open();
            try 
            {
                if (dataGridView3.Rows.Count > 0)
                {
                    DataRow dr = null;
                    for (int i = 0; i < dt.Rows.Count; i++)
                    {
                        dr = dt.Rows[i];
                        insertToSql_LSRY(dr);
                        insertToSql_LSRY2(dr);
                        xh++;
                    }
                    conn.Close();
                    MessageBox.Show("导入成功！");
                }
                else
                {
                    MessageBox.Show("没有数据！");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
            
        }

        private void button5_Click(object sender, EventArgs e)
        {
            if (textBox3.Text == "" || textBox4.Text == "")
            {
                MessageBox.Show("请输入完整信息！");
            }
            else 
            {
                SqlConnection connOpen = new SqlConnection(SQLHelper.connString);
                connOpen.Open();

                try
                {
                    SqlCommand cmd = new SqlCommand();
                    cmd.Connection = connOpen;
                    DateTime dt = DateTime.Now;
                    string y = dt.ToString("yyyyMMddhhmmss");
                    Random rd = new Random();

                    string a = "J" + y;
                    string b = textBox4.Text.Trim();
                    string sql = string.Format("insert into KXXB values('{0}','{1}','在用',0,null)", a, b);
                    SqlCommand sqlcmd = new SqlCommand(sql, connOpen);
                    sqlcmd.ExecuteNonQuery();

                    connOpen.Close();
                    connOpen.Dispose();
                    MessageBox.Show("录入成功！");
                }
                catch (Exception ex)
                {
                    MessageBox.Show("ERROR");
                }
            }

            
            
        }

        private void textBox4_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!(Char.IsNumber(e.KeyChar)) && e.KeyChar != (char)8) e.Handled = true;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            ds.Clear();
            string b;
            SqlConnection connOpen = new SqlConnection(SQLHelper.connString);
            connOpen.Open();
            if (comboBox1.SelectedIndex == 0)
                b = "TID";
            else
                b = "Tname";

            string a = textBox2.Text.Trim();
            
            string sqlse_SID = string.Format("select * from ZZGXXB where {0} = '{1}'", b, a);
            SqlCommand cmdse_SID = new SqlCommand(sqlse_SID, connOpen);
            cmdse_SID.ExecuteScalar();

            SqlCommand cmd = new SqlCommand();
            cmd.Connection = connOpen;
            string sql = null;
            if (comboBox1.Text == "姓名")

                sql = "select * from ZZGXXB where Tname ='" + textBox2.Text + "'";
            else if (comboBox1.Text == "工号")
                sql = "select * from ZZGXXB where TID ='" + textBox2.Text + "'";
            else
                MessageBox.Show("请选择查询条件");
            sda1 = new SqlDataAdapter(sql, connOpen);
            sda1.Fill(ds, "a");
            mydv = new DataView(ds.Tables["a"]);
            dataGridView2.DataSource = ds.Tables[0];

            connOpen.Close();
        }

        private void groupBox3_Enter(object sender, EventArgs e)
        {

        }

        private void textBox7_KeyPress(object sender, KeyPressEventArgs e)
        {
            //if (!(Char.IsNumber(e.KeyChar)) && e.KeyChar != (char)8) e.Handled = true;
        }

        private void dataGridView2_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            textBox3.Text = dataGridView2.Rows[e.RowIndex].Cells[1].Value.ToString();
            textBox4.Text = dataGridView2.Rows[e.RowIndex].Cells[0].Value.ToString();
        }

        private void textBox8_TextChanged(object sender, EventArgs e)
        {
            

        }

        private void button8_Click(object sender, EventArgs e)
        {
            conn = new SqlConnection(SQLHelper.connString);
            string sql1 = string.Format("select * from KXXB where SIDorTIDorPID = '{0}' and Cstatus = '停用'",textBox8.Text.Trim());
            ds2.Clear();
            sda1 = new SqlDataAdapter(sql1, conn);
            sda1.Fill(ds2, "a");
            mydv = new DataView(ds2.Tables["a"]);
            dataGridView4.DataSource = ds2.Tables[0];

        }

        private void button9_Click(object sender, EventArgs e)
        {

        }

        private void dataGridView4_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            textBox10.Text = dataGridView4.Rows[e.RowIndex].Cells[3].Value.ToString();
            textBox11.Text = dataGridView4.Rows[e.RowIndex].Cells[4].Value.ToString();
            oldCID = dataGridView4.Rows[e.RowIndex].Cells[0].Value.ToString();
            oldSTPID = dataGridView4.Rows[e.RowIndex].Cells[1].Value.ToString();

        }

        private void button9_Click_1(object sender, EventArgs e)
        {
            if (textBox10.Text != "")
            {
                DateTime dt = DateTime.Now;
                string y = dt.ToString("yyyyMMddhhmmss");
                Random rd = new Random();
                int w5 = rd.Next(10000, 99999);
                string a = "C" + y + Convert.ToString(w5);

                conn = new SqlConnection(SQLHelper.connString);
                conn.Open();
                string sql = string.Format("insert into KXXB values('{0}','{1}','在用',{2},'{3}')", a, oldSTPID, Convert.ToDouble(
                    textBox10.Text.Trim()), textBox11.Text.Trim());
                SqlCommand sqlcmd = new SqlCommand(sql, conn);
                sqlcmd.ExecuteNonQuery();

                string sql2 = string.Format("update KXXB set Cstatus = '注销',Money = 0 where CID = '{0}'", oldCID);
                SqlCommand sql2cmd = new SqlCommand(sql2, conn);
                sql2cmd.ExecuteNonQuery();

                textBox8.Text = "";
                textBox8.ReadOnly = false;
                textBox10.Text = "";
                textBox11.Text = "";

                string msb1 = string.Format("补办成功，您的新卡号是{0}", a);
                MessageBox.Show(msb1);

            }
            else
            {
                MessageBox.Show("搜不到就别补办啦，卡无了弟弟！");
            }



            

        }
    }
}
