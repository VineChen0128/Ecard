﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Ecard
{
    public partial class ChargeMoney : UserControl
    {
        

        public ChargeMoney()
        {
            InitializeComponent();
        }
        SqlConnection conn = null;

        private void UserControl1_Load(object sender, EventArgs e)
        {
            comboBox1.SelectedIndex = 0;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            
                conn = new SqlConnection(SQLHelper.connString);
                conn.Open();

                string A = textBox1.Text;

                string sql_1 = string.Format("select SIDorTIDorPID from KXXB where SIDorTIDorPID = '{0}'", A);
                SqlCommand cmdsql_1 = new SqlCommand(sql_1, conn);

                if (cmdsql_1.ExecuteScalar() == null)
                {
                    MessageBox.Show("请输入有效账号");
                }
                
                else
                {

                    if (comboBox1.SelectedIndex == 0)
                    {
                        string sql_5 = string.Format("select SID from XSXXB where SID = '{0}'", A);
                        SqlCommand cmdsql_5 = new SqlCommand(sql_5, conn);

                        if (cmdsql_5.ExecuteScalar() == null)
                        {
                            MessageBox.Show("请选择有效类型");
                        }
                        else 
                        {
                            string sql_2 = string.Format("select Sname from XSXXB where SID = '{0}'", A);
                            SqlCommand cmdsql_2 = new SqlCommand(sql_2, conn);
                            textBox3.Text = Convert.ToString(cmdsql_2.ExecuteScalar());
                        }
                        
                    }
                    else if (comboBox1.SelectedIndex == 1)
                    {
                        string sql_5 = string.Format("select TID from ZZGXXB where TID = '{0}'", A);
                        SqlCommand cmdsql_5 = new SqlCommand(sql_5, conn);

                        if (cmdsql_5.ExecuteScalar() == null)
                        {
                            MessageBox.Show("请选择有效类型");
                        }
                        else
                        {
                            string sql_2 = string.Format("select Tname from ZZGXXB where TID = '{0}'", A);
                            SqlCommand cmdsql_2 = new SqlCommand(sql_2, conn);
                            textBox3.Text = Convert.ToString(cmdsql_2.ExecuteScalar());
                        }
                        
                    }
                    else if (comboBox1.SelectedIndex == 2)
                    {
                        string sql_5 = string.Format("select PID from LSRYB where PID = '{0}'", A);
                        SqlCommand cmdsql_5 = new SqlCommand(sql_5, conn);

                        if (cmdsql_5.ExecuteScalar() == null)
                        {
                            MessageBox.Show("请选择有效类型");
                        }
                        else
                        {
                            string sql_2 = string.Format("select Pname from LSRYB where PID = '{0}'", A);
                            SqlCommand cmdsql_2 = new SqlCommand(sql_2, conn);
                            textBox3.Text = Convert.ToString(cmdsql_2.ExecuteScalar());
                        }
                        
                    }

                    string C = textBox4.Text;
                    string sql_3 = string.Format("select Money from KXXB where SIDorTIDorPID = '{0}'", A);
                    SqlCommand cmdsql_3 = new SqlCommand(sql_3, conn);
                    textBox4.Text = Convert.ToString(cmdsql_3.ExecuteScalar());

                    string D = textBox5.Text;
                    string sql_4 = string.Format("select Cstatus from KXXB where SIDorTIDorPID = '{0}'", A);
                    SqlCommand cmdsql_4 = new SqlCommand(sql_4, conn);
                    textBox5.Text = Convert.ToString(cmdsql_4.ExecuteScalar());

                    button2.Visible = true;

                    //("select {0} from {1} where SIDorTIDorPID = '{2}'",a,b,c)
                }
                conn.Close();
        }


        private void button2_Click_1(object sender, EventArgs e)
        {
            
            if (textBox2.Text == "")
            {
                MessageBox.Show("请输入充值金额！");
            }
            else
            {
                double a = Convert.ToDouble(textBox2.Text.Trim());
                conn = new SqlConnection(SQLHelper.connString);
                conn.Open();

                string A = textBox1.Text;

                string sql_1 = string.Format("select SIDorTIDorPID from KXXB where SIDorTIDorPID = '{0}'", A);
                SqlCommand cmdsql_1 = new SqlCommand(sql_1, conn);

                if (textBox2.Text == "")
                {
                    MessageBox.Show("请输入充值金额！");
                }
                else if (a < 10)
                {
                    MessageBox.Show("充值金额应大于10元！");
                }
                else if (a > 500)
                {
                    MessageBox.Show("充值金额应小于500元！");
                }
                else
                {
                    string sql_2 = string.Format("select CID from KXXB where SIDorTIDorPID = '{0}' and Cstatus = '在用'", A);
                    SqlCommand cmdsql_2 = new SqlCommand(sql_2, conn);
                    if (cmdsql_2.ExecuteScalar() != null)
                    {
                        try 
                        {
                            string sqlup = string.Format("update KXXB set money = Money + '" + textBox2.Text + "'  where SIDorTIDorPID = '{0}'", A);
                            SqlCommand cmdsqlup = new SqlCommand(sqlup, conn);
                            cmdsqlup.ExecuteNonQuery();
                            MessageBox.Show("充值成功");
                            //button3.Visible = true;
                        }
                        catch (Exception ex)
                        {
                            MessageBox.Show("充值已达上限！" + ex.ToString()); 
                        }
                        
                        

                        string sql_3 = string.Format("select Money from KXXB where SIDorTIDorPID = '{0}'", A);
                        SqlCommand cmdsql_3 = new SqlCommand(sql_3, conn);
                        textBox4.Text = Convert.ToString(cmdsql_3.ExecuteScalar());

                        string AA = textBox1.Text;
                        string sql_5 = string.Format("select CID from KXXB where SIDorTIDorPID = '{0}'", AA);
                        SqlCommand cmdsql_5 = new SqlCommand(sql_5, conn);
                        string B = Convert.ToString(cmdsql_1.ExecuteScalar());

                        double C = Convert.ToDouble(textBox2.Text);

                        DateTime dt = DateTime.Now;
                        string DID = "DH" + dt.ToString("yyyyMMddHHmmss");
                        string CID = B;
                        double ChargeMoney = C;
                        int ChargeWay = 0;
                        string PayID = null;
                        DateTime PayTime = dt;

                        string sql_4 = string.Format("insert into CZJLB values( '{0}','{1}',{2},{3},'{4}','{5}')", DID, CID, ChargeMoney, ChargeWay, PayID, PayTime);
                        SqlCommand cmdsql_4 = new SqlCommand(sql_4, conn);
                        cmdsql_4.ExecuteNonQuery();
                        MessageBox.Show("生成充值记录完成");

                        //button3.Visible = false;
                    }

                    else
                    {
                        MessageBox.Show("此卡状态不能充值");
                        //textBox6.Text = Convert.ToString(cmdsql_2.ExecuteScalar());
                    }
                }
                conn.Close();
            }
        }

        private void button3_Click_1(object sender, EventArgs e)
        {
            conn = new SqlConnection(SQLHelper.connString);
            conn.Open();

            
            conn.Close();

            }

        private void textBox2_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar != '\b')  
            {
                if ((e.KeyChar < '0') || (e.KeyChar > '9'))  
                {
                    e.Handled = true;
                }
            }
        }

        private void textBox1_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar != '\b') 
            {
                if ((e.KeyChar < '0') || ((e.KeyChar > '9') && (e.KeyChar < 'A')) || (e.KeyChar>'z'))  
                {
                    e.Handled = true;
                }
            }
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        } 
         
      }
    }

