﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Ecard
{
    public class SQLHelper
    {
        public static string connString = @"server = THINKPAD-PC\SQLEXPRESS;database = ceshi;User ID=sa;Password=sa";
    }
}
