﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Self_serviceTerminal
{
    public partial class RevocationForm : Form
    {

        
        public RevocationForm()
        {
            InitializeComponent();
        }
        string cxLID;
        string cxCID;
        string cxMID;
        double cxREMO;
        DateTime cxRETI;
        SqlConnection conn;

        private void button1_Click(object sender, EventArgs e)
        {
            string kh = textBox1.Text;
            conn = new SqlConnection(SQLHelper.connString);
            conn.Open();
            DataSet ds = new DataSet();
            string sql1 = "select * from LSXXB where CID='" + kh + "' and MID = '"+ LForm3.SJID +"'";
            SqlCommand cmd = new SqlCommand(sql1,conn);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(ds);
            dataGridView1.DataSource = ds.Tables[0];

            conn.Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            conn.Open();
            DateTime bjdt = DateTime.Now;
            if (textBox2.Text == "")
            {
                MessageBox.Show("请在左侧表格中选择需要撤销的一栏！");
            }
            else
            {
                string sel_4 = string.Format("Select ReturnTime from CHJLB where LID = '{0}'", textBox2.Text.Trim());
                SqlCommand cmdsel_4 = new SqlCommand(sel_4, conn);
                if (cmdsel_4.ExecuteScalar() != null)
                {
                    MessageBox.Show("该记录已撤回！");
                }
                else
                {
                    if (Convert.ToDateTime(cmdsel_4.ExecuteScalar()) > bjdt.AddHours(-1))
                    {
                        MessageBox.Show("该记录已过一小时时效，请与一卡通中心联系办理撤销！");
                    }
                    else 
                    {
                        DateTime dt = DateTime.Now;
                        string sqlse_SID = string.Format("insert into CHJLB values ('{0}','{1}','{2}','{3}','{4}')", cxLID, cxCID, cxMID, cxREMO, dt);
                        SqlCommand cmdse_SID = new SqlCommand(sqlse_SID, conn);
                        cmdse_SID.ExecuteScalar();

                        string sql_sel2 = string.Format("Select * from CHJLB where LID = '{0}'", cxLID);
                        SqlDataAdapter sda = new SqlDataAdapter(sql_sel2, conn);
                        DataSet ds2 = new DataSet();
                        sda.Fill(ds2);
                        DataTable dt2 = ds2.Tables[0];
                        dataGridView1.DataSource = dt2;

                        string sql_3 = string.Format("update KXXB set Money = Money + {0} where CID = '{1}'", cxREMO, cxCID);
                        SqlCommand cmdsql_3 = new SqlCommand(sql_3, conn);
                        cmdsql_3.ExecuteNonQuery();
                    }  
                }
            }
            conn.Close();
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            textBox2.Text = dataGridView1.Rows[e.RowIndex].Cells[0].Value.ToString();
            cxLID = dataGridView1.Rows[e.RowIndex].Cells[0].Value.ToString();
            cxCID = dataGridView1.Rows[e.RowIndex].Cells[1].Value.ToString();
            cxMID = dataGridView1.Rows[e.RowIndex].Cells[2].Value.ToString();
            cxREMO = Convert.ToDouble(dataGridView1.Rows[e.RowIndex].Cells[3].Value.ToString());
            cxRETI = Convert.ToDateTime(dataGridView1.Rows[e.RowIndex].Cells[4].Value.ToString());

        }
    }
}
