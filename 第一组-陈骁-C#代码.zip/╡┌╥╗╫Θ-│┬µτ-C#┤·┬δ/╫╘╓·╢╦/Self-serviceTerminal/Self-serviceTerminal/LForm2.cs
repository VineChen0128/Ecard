﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;


namespace Self_serviceTerminal
{
    public partial class LForm2 : Form
    {

        public LForm2()
        {
            InitializeComponent();
        }
        SqlConnection conn = null;
        public static string CardID;

        private void LForm2_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (textBox1.Text == "")
                MessageBox.Show("请输入编号", "警告", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            else if (textBox2.Text == "")
                MessageBox.Show("请输入密码", "警告", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            else
            {
                string usernum = textBox1.Text.Trim();
                string pw = textBox2.Text.Trim();

                conn = new SqlConnection(SQLHelper.connString);
                conn.Open();

                string s1 = "select * from KXXB where SIDorTIDorPID='" + usernum + "' and CID='" + pw + "'";
                SqlCommand mycom = new SqlCommand(s1, conn);

                if (mycom.ExecuteScalar() == null)
                {
                    MessageBox.Show("编号或卡号错误！");
                }
                else
                {
                    AutoSelect AS = new AutoSelect();
                    AS.ShowDialog();
                    CardID = pw;
                    this.Close();
                 }
                conn.Close();

                
            }
            
        }
    }
}
