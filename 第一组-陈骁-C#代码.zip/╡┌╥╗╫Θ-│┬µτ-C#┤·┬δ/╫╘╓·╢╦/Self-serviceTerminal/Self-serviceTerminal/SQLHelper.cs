﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Self_serviceTerminal
{
    public class SQLHelper
    {
        public static string connString = @"Data Source = (local); Initial Catalog = ceshi; Integrated Security = TRUE";
    }
}
