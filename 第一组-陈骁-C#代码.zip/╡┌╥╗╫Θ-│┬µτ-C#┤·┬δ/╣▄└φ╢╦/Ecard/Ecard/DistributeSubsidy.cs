﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Data.OleDb;

namespace Ecard
{
    public partial class DistributeSubsidy : UserControl
    {
        public DistributeSubsidy()
        {
            InitializeComponent();
        }

        SqlConnection conn;
        DataSet ds = new DataSet();
        DataView mydv = new DataView();
        SqlDataAdapter sda1 = null;
        DataTable dt = new DataTable();
        int xh = 10001;

        private void bind(string fileName)
        {
            try
            {
                string strConn = "Provider=Microsoft.Ace.OleDb.12.0;" +
                 "Data Source=" + fileName + ";" +
                 "Extended Properties='Excel 8.0; HDR=Yes; IMEX=1'";
                OleDbDataAdapter da = new OleDbDataAdapter("SELECT *  FROM [sheet1$]", strConn);
                DataSet ds = new DataSet();
                try
                {
                    da.Fill(ds);
                    dt = ds.Tables[0];
                    this.dataGridView2.DataSource = dt;
                }
                catch (Exception ex)
                {
                    MessageBox.Show("操作失败！选择文件类型不是EXCEL表格或表格table命名不正确" + ex.ToString());
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("请选择正确格式文件！" + ex.ToString());
            }
        }

        //private void insertToSql(DataRow dr)
        //{
        //    try
        //    {
        //        string a = dr["学号"].ToString();
        //        string b = dr["姓名"].ToString();
        //        string c = dr["金额"].ToString();
        //        string sql = "insert into XSXXB values('" + a + "','" + b + "','" + c + "')";
        //        //string sql = "insert into sheetname values('a','b','c','d')";
        //        SqlCommand cmd = new SqlCommand(sql, this.conn);
        //        cmd.ExecuteNonQuery();

        //    }
        //    catch (Exception ex)
        //    {
        //        MessageBox.Show("操作失败！EXCEL表格格式错误，或学生信息重复！" + ex.ToString());
        //    }

        //}

        private void button1_Click(object sender, EventArgs e)
        {
            ds.Clear();

            conn = new SqlConnection(SQLHelper.connString);
            conn.Open();


            string a = textBox1.Text.Trim();
            string sqlse_SID = string.Format("select SIDorTIDorPID  from KXXB where SIDorTIDorPID ='{0}'", a);
            SqlCommand cmdse_SID = new SqlCommand(sqlse_SID, conn);
            cmdse_SID.ExecuteScalar();


            if (cmdse_SID.ExecuteScalar() == null)// || textBox2.Text == "" || Convert.ToInt32(textBox2.Text) <= 0 )
            {
                MessageBox.Show("请输入正确学号及合法金额！");
            }
            else
            {
                double b = Convert.ToDouble(textBox2.Text);
                string sql_a = string.Format("select CID from KXXB where SIDorTIDorPID ='{0}'", a);
                SqlCommand cmdsql_a = new SqlCommand(sql_a, conn);

                DateTime dt = DateTime.Now;
                string ntime = "QG" + dt.ToString("yyyyMMddHHmmss");


                string sql = string.Format("insert into QGBZJLB(QID,CID,Qmoney) values ('{0}','{1}',{2})", ntime, cmdsql_a.ExecuteScalar(), b);
                SqlCommand cmd = new SqlCommand(sql, conn);
                cmd.ExecuteNonQuery();

                string sqlup = string.Format("update KXXB set Money = Money + {0} where CID = '{1}'", b, cmdsql_a.ExecuteScalar());
                SqlCommand cmdsqlup = new SqlCommand(sqlup, conn);
                cmdsqlup.ExecuteNonQuery();

                sda1 = new SqlDataAdapter("select QID 补助记录号,CID 卡号,QMONEY 发放金额 from QGBZJLB", conn);
                sda1.Fill(ds, "a");
                mydv = new DataView(ds.Tables["a"]);
                dataGridView1.DataSource = ds.Tables[0];
                conn.Close();

            }
            

        }

        private void DistributeSubsidy_Load(object sender, EventArgs e)
        {
            conn = new SqlConnection(SQLHelper.connString);
            conn.Open();
            ds.Clear();
            sda1 = new SqlDataAdapter("select QID 补助记录号,CID 卡号,QMONEY 发放金额 from QGBZJLB", conn);
            sda1.Fill(ds, "a");
            mydv = new DataView(ds.Tables["a"]);
            dataGridView1.DataSource = ds.Tables[0];

            conn.Close();

        }

        

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox2_KeyDown(object sender, KeyEventArgs e)
        {
            
        }

        private void textBox2_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar != '\b')//这是允许输入退格键  
            {
                if ((e.KeyChar < '0') || (e.KeyChar > '9'))//这是允许输入0-9数字  
                {
                    e.Handled = true;
                }
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            //try
            //{
            //    System.Windows.Forms.OpenFileDialog fd = new OpenFileDialog();
            //    if (fd.ShowDialog() == DialogResult.OK)
            //    {
            //        string fileName = fd.FileName;
            //        textBox1.Text = fileName;
            //        bind(fileName);
            //    }
            //}
            //catch (Exception ex)
            //{
            //    MessageBox.Show(ex.ToString());
            //}
        }
    }
}
